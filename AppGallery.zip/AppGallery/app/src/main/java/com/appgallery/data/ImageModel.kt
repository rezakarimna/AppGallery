package com.appgallery.data

data class ImageModel(var urlImage :String)
