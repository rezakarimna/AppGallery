package com.appgallery.ui.view

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.database.Cursor
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.GridLayoutManager
import com.appgallery.data.ImageModel
import com.appgallery.databinding.ActivityMainBinding
import com.appgallery.ui.adapter.AdapterGallery

class MainActivity : AppCompatActivity() {

    companion object {
        private const val STORAGE_PERMISSION_CODE = 101
    }

    private lateinit var binding: ActivityMainBinding
    private var imageList = ArrayList<ImageModel>()
    private lateinit var adapterGallery: AdapterGallery
    private val projections = arrayOf(MediaStore.Images.ImageColumns.DATA)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)
        if (Build.VERSION.SDK_INT < 23) {
            getAllImages()
            setAdapterGallery(this)
        } else {
            checkPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE, STORAGE_PERMISSION_CODE)
        }
    }

    private fun getAllImages() {
         imageList.clear()
        val cursor: Cursor? = contentResolver.query(
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            projections,
            null,
            null,
            null
        )

        while (cursor?.moveToNext() == true) {
            val absolutePathOfImage: String =
                cursor.getString(cursor.getColumnIndex(MediaStore.MediaColumns.DATA))
            val imageModel = ImageModel(absolutePathOfImage)
            imageList.add(imageModel)
        }

        cursor?.close()
    }

    private fun setAdapterGallery(context: Context) {
        binding.recyclerView.layoutManager = GridLayoutManager(context, 2)
        if (imageList.size == 0) {
            Toast.makeText(applicationContext, "لیست خالی می باشد", Toast.LENGTH_SHORT).show()
        } else {
            adapterGallery = AdapterGallery(imageList)
        }
        binding.recyclerView.adapter = adapterGallery
    }

    // Function to check and request permission.
    private fun checkPermission(permission: String, requestCode: Int) {
        if (ContextCompat.checkSelfPermission(
                this@MainActivity,
                permission
            ) == PackageManager.PERMISSION_DENIED
        ) {
            // Requesting the permission
            ActivityCompat.requestPermissions(this@MainActivity, arrayOf(permission), requestCode)
        } else {
            Toast.makeText(this@MainActivity, "قبلا دسترسی داده شده است", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == STORAGE_PERMISSION_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this@MainActivity, "Storage Permission Granted", Toast.LENGTH_SHORT)
                    .show()
                getAllImages()
                setAdapterGallery(this)
            } else {
                Toast.makeText(this@MainActivity, "Storage Permission Denied", Toast.LENGTH_SHORT)
                    .show()
            }
        }
    }
}


