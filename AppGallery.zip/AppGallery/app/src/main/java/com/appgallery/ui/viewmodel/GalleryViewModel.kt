package com.appgallery.ui.viewmodel

import com.appgallery.base.BaseViewModel

class GalleryViewModel : BaseViewModel() {

}